<?php
// El silencio es ORO!
